import ConvertImages from "../../Components/Convert-Images/Convert-Images";

export default function ImageConverter() {
  return (
    <div className="Convert-Images">
      <ConvertImages />
    </div>
  );
}
