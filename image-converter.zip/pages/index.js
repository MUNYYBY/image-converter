import LandingPage from "../Components/Landing-page/Landing-page";

export default function Home() {
  return <LandingPage />;
}
